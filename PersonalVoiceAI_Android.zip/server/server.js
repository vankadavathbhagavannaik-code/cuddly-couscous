import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

const port = process.env.PORT || 8787;
const apiKey = process.env.OPENAI_API_KEY;

if (!apiKey) {
  console.error("Missing OPENAI_API_KEY environment variable.");
  process.exit(1);
}

app.get("/", (req, res) => res.json({ ok: true, service: "Personal Voice AI" }));

app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "message is required" });

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-5.6-luna",
        instructions:
          "You are a friendly personal voice assistant. Speak naturally, be concise, helpful, and conversational. " +
          "Do not use markdown unless it improves clarity. The user will hear your response aloud.",
        input: message
      })
    });

    const data = await response.json();
    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message || "OpenAI request failed"
      });
    }

    res.json({ reply: data.output_text || "I didn't get a response." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Server error" });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Personal Voice AI server listening on http://0.0.0.0:${port}`);
});
