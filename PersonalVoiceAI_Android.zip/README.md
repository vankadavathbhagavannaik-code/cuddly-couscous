# Personal Voice AI — Android starter

A simple Android voice assistant:
- Tap the microphone
- Speak naturally
- Android converts speech to text
- The app sends the text to your private backend
- The backend calls OpenAI
- The app reads the answer aloud

## 1. Run the backend
Install Node.js 18+.

```bash
cd server
npm install
```

Set your API key as an environment variable:

Linux/macOS:
```bash
export OPENAI_API_KEY="your_key_here"
npm start
```

Windows PowerShell:
```powershell
$env:OPENAI_API_KEY="your_key_here"
npm start
```

The server listens on port 8787.

## 2. Build the Android app
Open the `android` folder in Android Studio, let Gradle sync, then run it on your Android phone.

In the app, enter the server URL:
- If the server is on the same Wi‑Fi network as the phone, use your computer's LAN IP, e.g. `http://192.168.1.20:8787`
- Do not use `localhost` unless the server is running on the phone itself.

## Security
Do NOT put your OpenAI API key in the Android app. Keep it on the backend. This starter intentionally uses a backend for that reason.

## Note
This first version uses Android's built-in speech recognition and text-to-speech. It is push-to-talk, not an always-listening wake-word assistant.
